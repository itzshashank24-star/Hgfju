# Bhoj Ki Khoj — Smart Meal Finder

Static HTML/CSS/JavaScript demo for GitHub Pages, backed by Supabase PostgreSQL.

## Files

- `index.html` — page markup
- `css/style.css` — responsive styles
- `js/config.js` — Supabase project URL and browser-safe publishable/anon key
- `js/meal-finder.js` — search, filters and distance calculation
- `supabase/schema.sql` — starter schema and read-only RLS policies

## Setup

1. In Supabase, open **SQL Editor** and run `supabase/schema.sql` in a development project. If you already have tables, compare and adapt the schema rather than blindly running it.
2. In `js/config.js`, replace `YOUR_PROJECT_REF` and `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY` with the project's URL and publishable/anon key.
3. Create a real authenticated test chef in Supabase Auth. Add a matching row to `chef_profiles` using that user's UUID, a kitchen name, `verification_status = 'verified'`, and test coordinates.
4. Add one or more test rows to `meals` with that chef UUID. Use valid `food_type` values (`veg`, `non_veg`, `vegan`, `jain`) and `meal_type` values (`breakfast`, `lunch`, `dinner`, `snacks`).
5. Commit and push the files to your GitHub repository.
6. In GitHub, open **Settings → Pages**, select the correct branch and folder (usually `main` and `/ (root)`), and save.
7. Open the published URL. The status message should report whether meals loaded.

## Security

- A Supabase publishable/anon key may be present in browser code only when RLS and access policies are configured correctly.
- NEVER put the Supabase `service_role` key or any secret key in a GitHub repository.
- The included SQL intentionally allows public read access only to verified chefs' available meals and verified public profiles. It does not create vendor write policies or an admin workflow.
- Use dummy/test data first. Do not expose private customer data or exact private addresses in public tables.

## Troubleshooting

- `Invalid API key`: copy the publishable/anon key from the correct Supabase project.
- `relation does not exist`: the actual table name differs or schema SQL was not run.
- `Could not find a relationship`: the `chef_id` foreign key differs from `meals_chef_id_fkey`; update the select expression in `meal-finder.js`.
- No meals appear: confirm the test chef is verified, the meal is available, the foreign key matches, and the row's chef UUID is correct.
- Location not working: allow browser location permission; test on the HTTPS GitHub Pages URL.
- Check browser DevTools → Console and Network for the precise error.
